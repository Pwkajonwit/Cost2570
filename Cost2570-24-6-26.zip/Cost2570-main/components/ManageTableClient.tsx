"use client";

import Link from "next/link";
import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import { ChevronLeft, ChevronRight, Eye, List, Pencil, Plus, Save, Trash2, X } from "lucide-react";
import { BillImageThumbnail } from "@/components/BillImageThumbnail";
import type { RowValue, SheetRow } from "@/lib/types";

type BusyState = "add" | "edit" | "delete" | null;
const PAGE_SIZE_OPTIONS = [50, 100];

type ManageTableClientProps = {
  tableName: string;
  viewName: string;
  columns: string[];
  formColumns: string[];
  rows: SheetRow[];
  keyColumn: string;
  search?: string;
  rowLabel?: string;
  detailBasePath?: string;
  addOpenEventName?: string;
  editOpenEventName?: string;
  displayLookups?: Record<string, Record<string, string>>;
};

export function ManageTableClient({
  tableName,
  viewName,
  columns,
  formColumns,
  rows: initialRows,
  keyColumn,
  search = "",
  rowLabel = "รายการ",
  detailBasePath,
  addOpenEventName,
  editOpenEventName,
  displayLookups = {}
}: ManageTableClientProps) {
  const visibleColumns = useMemo(() => columns.filter(column => column !== "_sheetRow"), [columns]);
  const addColumns = useMemo(() => formColumns.filter(column => column !== "_sheetRow"), [formColumns]);
  const [rows, setRows] = useState<SheetRow[]>(initialRows);
  const [addOpen, setAddOpen] = useState(false);
  const [addValues, setAddValues] = useState<Record<string, string>>(() => emptyValues(addColumns));
  const [editing, setEditing] = useState(false);
  const [deleteMode, setDeleteMode] = useState(false);
  const [draftRows, setDraftRows] = useState<Record<string, Record<string, string>>>({});
  const [selectedRows, setSelectedRows] = useState<number[]>([]);
  const [busy, setBusy] = useState<BusyState>(null);
  const [error, setError] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);
  const totalPages = Math.max(1, Math.ceil(rows.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const startIndex = (currentPage - 1) * pageSize;
  const visibleRows = rows.slice(startIndex, startIndex + pageSize);
  const visibleStart = visibleRows.length ? startIndex + 1 : 0;
  const visibleEnd = startIndex + visibleRows.length;

  useEffect(() => {
    setRows(initialRows);
  }, [initialRows]);

  useEffect(() => {
    setPage(1);
  }, [search, pageSize]);

  useEffect(() => {
    if (page > totalPages) setPage(totalPages);
  }, [page, totalPages]);

  useEffect(() => {
    setAddValues(emptyValues(addColumns));
  }, [addColumns]);

  async function reloadRows() {
    const params = new URLSearchParams({
      tableName,
      viewName,
      limit: "1000"
    });
    if (search) params.set("search", search);
    const response = await fetch(`/api/rows?${params.toString()}`, { cache: "no-store" });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || "โหลดข้อมูลไม่สำเร็จ");
    setRows(payload.rows || []);
  }

  function openAddForm() {
    setError("");
    if (addOpenEventName) {
      window.dispatchEvent(new Event(addOpenEventName));
      return;
    }
    setAddValues(emptyValues(addColumns));
    setAddOpen(true);
  }

  async function submitAdd(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy("add");
    setError("");
    try {
      await requestJson("/api/rows", {
        method: "POST",
        body: JSON.stringify({ tableName, row: addValues })
      });
      setAddOpen(false);
      await reloadRows();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "เพิ่มข้อมูลไม่สำเร็จ");
    } finally {
      setBusy(null);
    }
  }

  function beginEdit() {
    if (editOpenEventName) return;
    setError("");
    setDeleteMode(false);
    setSelectedRows([]);
    setDraftRows(Object.fromEntries(rows.map((row, index) => [rowId(row, index, keyColumn), draftFromRow(row, visibleColumns)])));
    setEditing(true);
  }

  function cancelEdit() {
    setEditing(false);
    setDraftRows({});
    setError("");
  }

  function updateDraft(id: string, column: string, value: string) {
    setDraftRows(current => ({
      ...current,
      [id]: {
        ...(current[id] || {}),
        [column]: value
      }
    }));
  }

  async function saveEdit() {
      const changedRows = rows.flatMap((row, index) => {
      const id = rowId(row, index, keyColumn);
      const draft = draftRows[id];
      const sheetRow = Number(row._sheetRow);
      if (!draft || !Number.isInteger(sheetRow)) return [];
      const values = changedValues(row, draft, visibleColumns);
      return Object.keys(values).length ? [{ sheetRow, values }] : [];
    });

    if (!changedRows.length) {
      setEditing(false);
      setDraftRows({});
      return;
    }

    setBusy("edit");
    setError("");
    try {
      for (const changedRow of changedRows) {
        await requestJson("/api/rows", {
          method: "PATCH",
          body: JSON.stringify({ tableName, sheetRow: changedRow.sheetRow, values: changedRow.values })
        });
      }
      setEditing(false);
      setDraftRows({});
      await reloadRows();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "บันทึกข้อมูลไม่สำเร็จ");
    } finally {
      setBusy(null);
    }
  }

  function beginDelete() {
    setError("");
    setEditing(false);
    setDraftRows({});
    setSelectedRows([]);
    setDeleteMode(true);
  }

  function openSchemaEdit(row: SheetRow) {
    if (!editOpenEventName) return;
    const sheetRow = Number(row._sheetRow);
    if (!Number.isInteger(sheetRow)) {
      setError("ไม่พบตำแหน่งแถวใน Sheet สำหรับแก้ไข");
      return;
    }
    setError("");
    window.dispatchEvent(new CustomEvent(editOpenEventName, { detail: { row, sheetRow } }));
  }

  function toggleSelected(sheetRow: number) {
    setSelectedRows(current => current.includes(sheetRow) ? current.filter(row => row !== sheetRow) : [...current, sheetRow]);
  }

  async function confirmDelete() {
    if (!selectedRows.length) {
      setError("เลือกแถวที่ต้องการลบก่อน");
      return;
    }
    if (!window.confirm(`ลบ ${selectedRows.length} ${rowLabel}?`)) return;

    setBusy("delete");
    setError("");
    try {
      await requestJson("/api/rows", {
        method: "DELETE",
        body: JSON.stringify({ tableName, sheetRows: selectedRows })
      });
      setDeleteMode(false);
      setSelectedRows([]);
      await reloadRows();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "ลบข้อมูลไม่สำเร็จ");
    } finally {
      setBusy(null);
    }
  }

  return (
    <>
      <div className="panel table-shell manage-table-shell">
        <div className="table-toolbar manage-toolbar">
          <div>
            <h3>{viewName}</h3>
            <span>{search ? `Search: ${search}` : tableName}</span>
          </div>
          <div className="manage-actions">
            <button type="button" className="primary" disabled={Boolean(busy)} onClick={openAddForm}>
              <Plus size={15} />
              <span>เพิ่ม</span>
            </button>
            {editing ? (
              <>
                <button type="button" className="primary" disabled={busy === "edit"} onClick={saveEdit}>
                  <Save size={15} />
                  <span>บันทึก</span>
                </button>
                <button type="button" disabled={Boolean(busy)} onClick={cancelEdit}>
                  <X size={15} />
                  <span>ยกเลิก</span>
                </button>
              </>
            ) : editOpenEventName ? null : (
              <button type="button" disabled={Boolean(busy) || !rows.length} onClick={beginEdit}>
                <Pencil size={15} />
                <span>แก้ไข</span>
              </button>
            )}
            {deleteMode ? (
              <>
                <button type="button" className="danger-button" disabled={busy === "delete" || !selectedRows.length} onClick={confirmDelete}>
                  <Trash2 size={15} />
                  <span>ลบที่เลือก</span>
                </button>
                <button type="button" disabled={Boolean(busy)} onClick={() => { setDeleteMode(false); setSelectedRows([]); }}>
                  <X size={15} />
                  <span>ยกเลิก</span>
                </button>
              </>
            ) : (
              <button type="button" className="danger-button" disabled={Boolean(busy) || !rows.length} onClick={beginDelete}>
                <Trash2 size={15} />
                <span>ลบ</span>
              </button>
            )}
          </div>
        </div>
        {error ? <div className="manage-error">{error}</div> : null}
        {rows.length ? (
          <div className="manage-table-wrap">
            <table className={editing ? "manage-table is-editing" : "manage-table"}>
              <thead>
                <tr>
                  {deleteMode ? <th className="manage-select-col"></th> : null}
                  {(detailBasePath || editOpenEventName) && !editing && !deleteMode ? <th className="manage-detail-col">จัดการ</th> : null}
                  {visibleColumns.map(column => <th key={column}>{column}</th>)}
                </tr>
              </thead>
              <tbody>
                {visibleRows.map((row, index) => {
                  const rowIndex = startIndex + index;
                  const id = rowId(row, rowIndex, keyColumn);
                  const sheetRow = Number(row._sheetRow);
                  return (
                    <tr key={id}>
                      {deleteMode ? (
                        <td className="manage-select-col" data-label="เลือก">
                          <input
                            type="checkbox"
                            checked={selectedRows.includes(sheetRow)}
                            disabled={!Number.isInteger(sheetRow) || Boolean(busy)}
                            onChange={() => toggleSelected(sheetRow)}
                          />
                        </td>
                      ) : null}
                      {(detailBasePath || editOpenEventName) && !editing && !deleteMode ? (
                        <td className="manage-detail-col" data-label="ดู">
                          <div className="manage-row-actions">
                            {detailBasePath ? (
                              <Link
                                className="detail-link-button detail-icon-button"
                                href={`${detailBasePath}/${encodeURIComponent(String(row[keyColumn] || ""))}`}
                                aria-label="ดูรายละเอียด"
                                title="ดูรายละเอียด"
                              >
                                <Eye size={16} />
                              </Link>
                            ) : null}
                            {editOpenEventName ? (
                              <button
                                type="button"
                                className="detail-link-button detail-icon-button detail-edit-row-button"
                                disabled={Boolean(busy)}
                                onClick={() => openSchemaEdit(row)}
                                aria-label="แก้ไข"
                                title="แก้ไข"
                              >
                                <Pencil size={16} />
                              </button>
                            ) : null}
                          </div>
                        </td>
                      ) : null}
                      {visibleColumns.map(column => {
                        const draftValue = draftRows[id]?.[column] ?? stringify(row[column]);
                        return (
                          <td key={column} className={isAmountColumn(column) ? "numeric-cell" : undefined} data-label={column}>
                            {editing ? (
                              <input
                                className="manage-cell-input"
                                value={draftValue}
                                disabled={Boolean(busy)}
                                onChange={event => updateDraft(id, column, event.target.value)}
                              />
                            ) : (
                              renderDisplayCell(column, row[column], displayLookups)
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="empty-state">ไม่พบข้อมูล</div>
        )}
        {rows.length ? (
          <ManagePagination
            currentPage={currentPage}
            onPageChange={setPage}
            onPageSizeChange={setPageSize}
            pageSize={pageSize}
            rowLabel={rowLabel}
            totalPages={totalPages}
            totalRows={rows.length}
            visibleEnd={visibleEnd}
            visibleStart={visibleStart}
          />
        ) : null}
      </div>

      {addOpen ? (
        <div className="modal-backdrop" role="presentation">
          <form className="modal-card manage-modal" role="dialog" aria-modal="true" aria-labelledby="manage-add-title" onSubmit={submitAdd}>
            <header className="modal-header">
              <div>
                <h3 id="manage-add-title">เพิ่มข้อมูล</h3>
                <span>{viewName}</span>
              </div>
              <button type="button" className="icon-button" aria-label="ปิด" disabled={Boolean(busy)} onClick={() => setAddOpen(false)}>
                <X size={18} />
              </button>
            </header>
            <div className="modal-body">
              <div className="manage-form-grid">
                {addColumns.map(column => (
                  <label className="manage-form-field" key={column}>
                    <span>{column}</span>
                    <input
                      name={column}
                      value={addValues[column] || ""}
                      disabled={Boolean(busy)}
                      onChange={event => setAddValues(current => ({ ...current, [column]: event.target.value }))}
                    />
                  </label>
                ))}
              </div>
              {error ? <div className="manage-error manage-error-modal">{error}</div> : null}
            </div>
            <footer className="modal-footer">
              <button type="button" disabled={Boolean(busy)} onClick={() => setAddOpen(false)}>ยกเลิก</button>
              <button type="submit" className="primary" disabled={busy === "add"}>
                <Save size={16} />
                <span>บันทึก</span>
              </button>
            </footer>
          </form>
        </div>
      ) : null}
    </>
  );
}

function emptyValues(columns: string[]) {
  return Object.fromEntries(columns.map(column => [column, ""]));
}

function ManagePagination({
  currentPage,
  onPageChange,
  onPageSizeChange,
  pageSize,
  rowLabel,
  totalPages,
  totalRows,
  visibleEnd,
  visibleStart
}: {
  currentPage: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (pageSize: number) => void;
  pageSize: number;
  rowLabel: string;
  totalPages: number;
  totalRows: number;
  visibleEnd: number;
  visibleStart: number;
}) {
  const pages = pageWindow(currentPage, totalPages);
  return (
    <div className="table-pagination manage-pagination" aria-label="pagination">
      <div className="pagination-summary">
        <span className="pagination-summary-full">แสดง {visibleStart}-{visibleEnd} จาก {totalRows} {rowLabel}</span>
        <span className="pagination-summary-compact" aria-label={`แสดง ${visibleStart}-${visibleEnd} จาก ${totalRows} ${rowLabel}`}>
          {visibleStart}-{visibleEnd}/{totalRows}
        </span>
        <div className="page-size-switch" aria-label="rows per page">
          <span className="page-size-label">
            <List size={15} aria-hidden="true" />
            <span>ต่อหน้า</span>
          </span>
          {PAGE_SIZE_OPTIONS.map(option => (
            <button
              key={option}
              type="button"
              className={option === pageSize ? "active" : ""}
              aria-current={option === pageSize ? "true" : undefined}
              onClick={() => onPageSizeChange(option)}
            >
              {option}
            </button>
          ))}
        </div>
      </div>
      <nav className="pagination-controls" aria-label="table pages">
        <PageButton className="pagination-prev" disabled={currentPage <= 1} onClick={() => onPageChange(currentPage - 1)}>
          <ChevronLeft className="pagination-link-icon" size={15} aria-hidden="true" />
          <span className="pagination-link-text">ก่อนหน้า</span>
        </PageButton>
        {pages.map((page, index) => (
          page === "ellipsis" ? (
            <span className="page-ellipsis" key={`ellipsis-${index}`}>...</span>
          ) : (
            <button
              key={page}
              type="button"
              className={page === currentPage ? "active" : ""}
              aria-current={page === currentPage ? "page" : undefined}
              onClick={() => onPageChange(page)}
            >
              {page}
            </button>
          )
        ))}
        <PageButton className="pagination-next" disabled={currentPage >= totalPages} onClick={() => onPageChange(currentPage + 1)}>
          <span className="pagination-link-text">ถัดไป</span>
          <ChevronRight className="pagination-link-icon" size={15} aria-hidden="true" />
        </PageButton>
      </nav>
    </div>
  );
}

function PageButton({ children, className, disabled, onClick }: { children: ReactNode; className?: string; disabled: boolean; onClick: () => void }) {
  const buttonClassName = className ? `page-nav-link ${className}` : "page-nav-link";
  return (
    <button type="button" className={buttonClassName} disabled={disabled} onClick={onClick}>
      {children}
    </button>
  );
}

function pageWindow(currentPage: number, totalPages: number) {
  if (totalPages <= 7) return Array.from({ length: totalPages }, (_, index) => index + 1);
  const pages: Array<number | "ellipsis"> = [1];
  const start = Math.max(2, currentPage - 1);
  const end = Math.min(totalPages - 1, currentPage + 1);
  if (start > 2) pages.push("ellipsis");
  for (let page = start; page <= end; page += 1) pages.push(page);
  if (end < totalPages - 1) pages.push("ellipsis");
  pages.push(totalPages);
  return pages;
}

function rowId(row: SheetRow, index: number, keyColumn: string) {
  return String(row._sheetRow ?? row[keyColumn] ?? index);
}

function draftFromRow(row: SheetRow, columns: string[]) {
  return Object.fromEntries(columns.map(column => [column, stringify(row[column])]));
}

function changedValues(row: SheetRow, draft: Record<string, string>, columns: string[]) {
  return Object.fromEntries(
    columns
      .filter(column => stringify(row[column]) !== (draft[column] ?? ""))
      .map(column => [column, draft[column] ?? ""])
  );
}

async function requestJson(url: string, init: RequestInit) {
  const response = await fetch(url, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init.headers || {})
    }
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.error || "ดำเนินการไม่สำเร็จ");
  return payload;
}

function stringify(value: RowValue | undefined) {
  if (value === null || value === undefined) return "";
  return String(value);
}

function formatValue(value: RowValue | undefined, column = "") {
  if (value === null || value === undefined) return "";
  if (typeof value === "number") return value.toLocaleString("th-TH", { maximumFractionDigits: 2 });
  if (isAmountColumn(column)) {
    const parsed = Number(String(value).replace(/,/g, ""));
    if (Number.isFinite(parsed) && String(value).trim() !== "") {
      return parsed.toLocaleString("th-TH", { maximumFractionDigits: 2 });
    }
  }
  return String(value);
}

function renderDisplayCell(column: string, value: RowValue | undefined, displayLookups: Record<string, Record<string, string>>) {
  if (isImageColumn(column)) return <BillImageThumbnail value={value} />;
  if (column === "color") return <ColorDot value={value} />;
  const rawValue = stringify(value);
  const lookup = displayLookups[column];
  if (lookup && rawValue) return lookup[rawValue] || rawValue;
  return formatValue(value, column);
}

function ColorDot({ value }: { value: RowValue | undefined }) {
  const label = stringify(value).trim();
  const tone = label.toLowerCase();
  const className = tone === "green"
    ? "color-dot color-dot-green"
    : tone === "red"
      ? "color-dot color-dot-red"
      : tone === "black"
        ? "color-dot color-dot-black"
        : "color-dot color-dot-empty";
  return (
    <span className="color-dot-wrap" title={label || "-"}>
      <span className={className} aria-label={label || "-"} />
    </span>
  );
}

function isImageColumn(column: string) {
  return column === "image" || column.includes("รูปถ่าย") || column.toLowerCase().includes("image");
}

function isAmountColumn(column: string) {
  return /ยอด|เงิน|ราคา|vat|หัก|เครดิต|ค่าแรง|รวม|คงเหลือ|โอน|งบ/.test(column);
}
